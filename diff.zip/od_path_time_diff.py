## Imports
from allPath import AllPath

class ODDiff():
    def __init__(self,sc):
        ap = AllPath(sc)
	sl,self.sp = ap.getSql()
	self.od = sc.textFile("res")

    def getTimes(self,x):
        L = x.split(',')
	res = self.sp.where(self.sp.start == L[2]) \
	    .where(self.sp.end == L[4]) \
	    .orderBy(self.sp.time) \
	    .select(self.sp.time).collect()
	ress = [x[0] for x in res]
	return x+','+str(int(L[-1]) - ress[0])+','+str(int(L[-1]) - ress[-1])

    def getDiff(self):
        return self.od.map(getTimes)
